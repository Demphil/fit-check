/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

// This component is not used in the current application flow.
const FilterPanel = () => null;
export default FilterPanel;
